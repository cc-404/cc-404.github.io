#include <stdio.h>
#include "defs.h"
void keyExpand(unsigned int key, _BYTE *outKey);
void XTEA(_BYTE *userkey, _BYTE *in, _BYTE *out);

void keyExpand(unsigned int key, _BYTE *outKey)
{
  int i; // r0

  for ( i = 0; i < 16; i = (i + 1) )
    *(i + outKey) = key >> (8 * (3 - i % 4));
}

void XTEA(_BYTE *userkey, _BYTE *in, _BYTE *out)
{
  unsigned int v3; // r3
  unsigned int v4; // r4
  unsigned int v5; // r5
  unsigned int i; // r6
  int v7[4]; // [sp+0h] [bp-34h]
  unsigned int v8; // [sp+10h] [bp-24h]
  unsigned int v9; // [sp+14h] [bp-20h]

  char aStefanlovesmay[] = "StefanLovesMaya!";

  if ( userkey !=0  && in!=0 && out!=0 )
  {
    v8 = (*in << 24) + (in[1] << 16) + (in[2] << 8) + in[3];
    v9 = (in[4] << 24) + (in[5] << 16) + (in[6] << 8) + in[7];
    v7[0] = (userkey[3] ^ aStefanlovesmay[3])
          + ((*userkey ^ aStefanlovesmay[0]) << 24)
          + ((userkey[1] ^ aStefanlovesmay[1]) << 16)
          + ((userkey[2] ^ aStefanlovesmay[2]) << 8);
    v7[1] = (userkey[7] ^ aStefanlovesmay[7])
          + ((userkey[4] ^ aStefanlovesmay[4]) << 24)
          + ((userkey[5] ^ aStefanlovesmay[5]) << 16)
          + ((userkey[6] ^ aStefanlovesmay[6]) << 8);
    v7[2] = (userkey[11] ^ aStefanlovesmay[11])
          + ((userkey[8] ^ aStefanlovesmay[8]) << 24)
          + ((userkey[9] ^ aStefanlovesmay[9]) << 16)
          + ((userkey[10] ^ aStefanlovesmay[10]) << 8);
    v7[3] = (userkey[15] ^ aStefanlovesmay[15])
          + ((userkey[12] ^ aStefanlovesmay[12]) << 24)
          + ((userkey[13] ^ aStefanlovesmay[13]) << 16)
          + ((userkey[14] ^ aStefanlovesmay[14]) << 8);
    v3 = v8;
    v4 = v9;
    v5 = 0;
    for ( i = 0; i < 0x20; ++i )
    {
      v3 += (((16 * v4) ^ (v4 >> 5)) + v4) ^ (v7[v5 & 3] + v5);
      v5 -= -0x9E3779B9;
      v4 += (((16 * v3) ^ (v3 >> 5)) + v3) ^ (v7[(v5 >> 11) & 3] + v5);
    }
    *out = HIBYTE(v3);
    out[1] = BYTE2(v3);
    out[2] = BYTE1(v3);
    out[3] = v3;
    out[4] = HIBYTE(v4);
    out[5] = BYTE2(v4);
    out[6] = BYTE1(v4);
    out[7] = v4;
  }
}

int main() {
    unsigned int key=0xBA2F96A9;
    _BYTE outKey[16];
    
    keyExpand(key, outKey);
    printf("outKey: ");
    for (int i=0; i<16; i++) {
        printf("%02x ", outKey[i]);
    }
    printf("\n");
    // _BYTE in[] = {0x10, 0xBE, 0x62, 0xF8, 0xE8, 0xDC, 0x34, 0x46};
    _BYTE in[] ={0x0E, 0x77, 0x50, 0xC8, 0xC6, 0x27, 0xE1, 0xBF};
    _BYTE out[8];
    printf("in: ");
    for (int i=0; i<8; i++) {
        printf("%02x ", in[i]);
    }
    printf("\n");
    XTEA(outKey, in, out);

    printf("out: ");
    for (int i=0; i<8; i++) {
        printf("%02x ", out[i]);
    }
    return 0;
}