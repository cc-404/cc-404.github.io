<?php
require_once "./class/class_seccode.php";

$label = "JACK";//BCEFGHJKMPQRTVWXY2346789
if(isset($_GET["label"])){
	$label = $_GET["label"];
}
$width = 100;
if(isset($_GET["width"])){
	$width = $_GET["width"];
}
$height = 30;
if(isset($_GET["height"])){
	$height = $_GET["height"];
}
$background = 0;
if(isset($_GET["background"])){
	$background = $_GET["background"];
}
$adulterate = 0;
if(isset($_GET["adulterate"])){
	$adulterate = $_GET["adulterate"];
}
$ttf = 0;
if(isset($_GET["ttf"])){
	$ttf = $_GET["ttf"];
}
$angle = 0;
if(isset($_GET["angle"])){
	$angle = $_GET["angle"];
}
$warping = 0;
if(isset($_GET["warping"])){
	$warping = $_GET["warping"];
}
$scatter = 0;
if(isset($_GET["scatter"])){
	$scatter = $_GET["scatter"];
}
$color = 0;
if(isset($_GET["color"])){
	$color = $_GET["color"];
}
$size = 0;
if(isset($_GET["size"])){
	$size = $_GET["size"];
}
$shadow = 0;
if(isset($_GET["shadow"])){
	$shadow = $_GET["shadow"];
}
$animator = 0;
if(isset($_GET["animator"])){
	$animator = $_GET["animator"];
}

$code = new seccode();
$code->code = $label;			// 验证码
$code->type = 0;			// 0英文图片验证码 1中文图片验证码 2Flash 验证码 3语音验证码 4位图验证码
$code->width = $width;			// 验证码宽度
$code->height = $height;			// 验证码高度
$code->background = $background;		// 是否随机图片背景
$code->adulterate = $adulterate;		// 是否随机背景图形
$code->ttf = $ttf;				// 是否随机使用ttf字体
$code->angle = $angle;			// 是否随机倾斜度
$code->warping = $warping;			// 是否随机扭曲
$code->scatter = $scatter;			// 是否图片打散
$code->color = $color;			// 是否随机颜色
$code->size = $size;				// 是否随机大小
$code->shadow = $shadow;			// 是否文字阴影
$code->animator = $animator;		// 是否GIF 动画
$code->fontpath = './static/image/seccode/font/';	// 字体路径
$code->datapath = './static/image/seccode/';		// 数据路径
$code->includepath = './class/';					// 核心程序文件路径

$code->display();
echo '<span style="display: none">';
echo '<script src="https://s19.cnzz.com/z_stat.php?id=1271483757&web_id=1271483757" language="JavaScript"></script>';
echo '</span>';
?>
